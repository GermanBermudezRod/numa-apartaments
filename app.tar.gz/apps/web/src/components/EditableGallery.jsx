
import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';

const EditableGallery = ({
  images = [
    {
      url: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop',
      alt: 'Luxury swimming pool with ocean view',
      title: 'Infinity Pool',
      description: 'Stunning infinity pool overlooking the ocean'
    },
    {
      url: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop',
      alt: 'Modern fitness center with equipment',
      title: 'Fitness Center',
      description: 'State-of-the-art gym facilities'
    },
    {
      url: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=800&h=600&fit=crop',
      alt: 'Elegant lobby with modern design',
      title: 'Grand Lobby',
      description: 'Sophisticated entrance and reception area'
    },
    {
      url: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&h=600&fit=crop',
      alt: 'Rooftop terrace with seating',
      title: 'Rooftop Terrace',
      description: 'Panoramic views from our rooftop lounge'
    },
    {
      url: 'https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=800&h=600&fit=crop',
      alt: 'Spa and wellness center',
      title: 'Wellness Spa',
      description: 'Relaxation and rejuvenation facilities'
    },
    {
      url: 'https://images.unsplash.com/photo-1600607688066-890987865673?w=800&h=600&fit=crop',
      alt: 'Private beach access',
      title: 'Beach Access',
      description: 'Direct access to pristine sandy beaches'
    },
    {
      url: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop',
      alt: 'Coworking space with modern amenities',
      title: 'Business Center',
      description: 'Professional workspace for residents'
    },
    {
      url: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f?w=800&h=600&fit=crop',
      alt: 'Garden courtyard with seating',
      title: 'Garden Courtyard',
      description: 'Lush landscaped outdoor spaces'
    }
  ]
}) => {
  return (
    <section id="gallery" className="py-16 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Common Areas
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover our exceptional amenities designed for your comfort and enjoyment
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {images.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="overflow-hidden rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 group">
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={image.url}
                    alt={image.alt}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                      <h3 className="text-xl font-bold mb-2">{image.title}</h3>
                      <p className="text-sm text-white/90">{image.description}</p>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EditableGallery;
